﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public void ThrowPickUp()
    {
        print("撿起物件");
    }
    public void ThrowOetach()
    {
        print("放開物件");
    }
    public void ThrowHold()
    {
        print("拿著物件");
    }
}